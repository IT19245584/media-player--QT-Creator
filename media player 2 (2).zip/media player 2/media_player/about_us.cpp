#include "about_us.h"
#include "ui_about_us.h"
#include "mainwindow.h"

about_us::about_us(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::about_us)
{
    ui->setupUi(this);
}

about_us::~about_us()
{
    delete ui;
}

void about_us::on_pushButton_clicked()
{
    close();
}

