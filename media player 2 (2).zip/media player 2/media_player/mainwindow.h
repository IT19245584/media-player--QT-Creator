#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QFileDialog>
#include <QProgressBar>
#include <QSlider>

#include "about_us.h"
#include "mp3_player_.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionOpen_2_triggered();

    void on_actionplay_triggered();

    void on_actionStop_triggered();

    void on_actionPause_triggered();

    void on_actionOpen_triggered();

    void on_actionExit_triggered();



    void on_actionAbout_triggered();

    void on_actionWeb_Camera_triggered();

    void on_mp3_player_triggered();

    void on_actionMP3_Player_triggered();

    void on_actionMP3_Player_2_triggered();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
     about_us  *about;
     mp3_player_  *players;

    QMediaPlayer *player;
    QVideoWidget *vw;
    QProgressBar *bar;
    QSlider *slider;



};
#endif // MAINWINDOW_H
