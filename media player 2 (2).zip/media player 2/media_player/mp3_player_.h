#ifndef MP3_PLAYER__H
#define MP3_PLAYER__H

#include <QMainWindow>
#include "about_us.h"

namespace Ui {
class mp3_player_;
}

class QMediaPlayer;
class mp3_player_ : public QMainWindow
{
    Q_OBJECT

public:
    explicit mp3_player_(QWidget *parent = nullptr);
    ~mp3_player_();

private slots:
    void on_actionExit_triggered();
    void on_actionAbout_triggered();
    void on_file_clicked();
    void on_play_clicked();
    void on_pause_clicked();
    void on_stop_clicked();
    void on_mute_clicked();
    void on_volume_sliderMoved(int position);
    void on_volume_valueChanged(int value);

    void on_actionVideo_Player_triggered();

private:
    Ui::mp3_player_ *ui;
    about_us  *about;

    QMediaPlayer *mQMediaPlayer;
};

#endif // MP3_PLAYER__H
