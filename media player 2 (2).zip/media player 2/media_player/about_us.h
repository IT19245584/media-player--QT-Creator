#ifndef ABOUT_US_H
#define ABOUT_US_H

#include <QDialog>

namespace Ui {
class about_us;
}

class about_us : public QDialog
{
    Q_OBJECT

public:
    explicit about_us(QWidget *parent = nullptr);
    ~about_us();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_2_clicked(bool checked);

private:
    Ui::about_us *ui;
};

#endif // ABOUT_US_H
