#include "mp3_player_.h"
#include "ui_mp3_player_.h"

#include <QMediaPlayer>
#include <QFileDialog>

mp3_player_::mp3_player_(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mp3_player_)
{
    ui->setupUi(this);
    mQMediaPlayer = new QMediaPlayer(this);
    connect(mQMediaPlayer,&QMediaPlayer::positionChanged,[&](qint64 pos){
        ui->progressBar->setValue(pos);
    });

    connect(mQMediaPlayer,&QMediaPlayer::durationChanged,[&](qint64 dur){
        ui->progressBar->setMaximum(dur);
    });
}

mp3_player_::~mp3_player_()
{
    delete ui;
}

void mp3_player_::on_actionExit_triggered()
{
    close();
}

void mp3_player_::on_actionAbout_triggered()
{
    about = new about_us(this);
    about->show();
}

void mp3_player_::on_file_clicked()
{
   QString filename = QFileDialog::getOpenFileName(this,"File");
   if(filename.isEmpty()){
       return;
   }
   mQMediaPlayer->setMedia(QUrl::fromLocalFile(filename));
   mQMediaPlayer->setVolume(ui->volume->value());
   on_play_clicked();
}

void mp3_player_::on_play_clicked()
{
  mQMediaPlayer ->play();
}

void mp3_player_::on_pause_clicked()
{
 mQMediaPlayer ->pause();
}

void mp3_player_::on_stop_clicked()
{
 mQMediaPlayer ->stop();
}

void mp3_player_::on_mute_clicked()
{
  if(ui->mute->text()=="Mute"){
      mQMediaPlayer->setMuted(true);
      ui->mute->setText("Unmute");
  }else{
      mQMediaPlayer->setMuted(false);
      ui->mute->setText("Mute");
  }
}



void mp3_player_::on_volume_valueChanged(int value)
{
  mQMediaPlayer->setVolume(value);
}

void mp3_player_::on_actionVideo_Player_triggered()
{

}
