/********************************************************************************
** Form generated from reading UI file 'about_us.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_US_H
#define UI_ABOUT_US_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_about_us
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *about_us)
    {
        if (about_us->objectName().isEmpty())
            about_us->setObjectName(QString::fromUtf8("about_us"));
        about_us->resize(465, 356);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/icons8-stop-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        about_us->setWindowIcon(icon);
        pushButton = new QPushButton(about_us);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(350, 300, 93, 33));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        font.setWeight(50);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("background :rgb(0, 85, 255);\n"
"color:white;\n"
"border-radius:5px;"));
        label = new QLabel(about_us);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 40, 691, 281));
        label_2 = new QLabel(about_us);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 80, 191, 31));
        QFont font1;
        font1.setPointSize(13);
        font1.setBold(true);
        font1.setWeight(75);
        label_2->setFont(font1);

        retranslateUi(about_us);

        QMetaObject::connectSlotsByName(about_us);
    } // setupUi

    void retranslateUi(QDialog *about_us)
    {
        about_us->setWindowTitle(QCoreApplication::translate("about_us", "About Us", nullptr));
        pushButton->setText(QCoreApplication::translate("about_us", "Exit", nullptr));
        label->setText(QCoreApplication::translate("about_us", "\n"
"Based on Qt 5.15.2 (MSVC 2019, 64 bit)\n"
"\n"
"Built on Dec 17 2020 07:57:20\n"
"\n"
"From revision 909f74dc56\n"
"\n"
"Copyright 2008-2020 The Qt Company Ltd. All rights reserved.", nullptr));
        label_2->setText(QCoreApplication::translate("about_us", "Qt Creator 4.14.0", nullptr));
    } // retranslateUi

};

namespace Ui {
    class about_us: public Ui_about_us {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_US_H
