/********************************************************************************
** Form generated from reading UI file 'mp3_player.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MP3_PLAYER_H
#define UI_MP3_PLAYER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mp3_player
{
public:

    void setupUi(QWidget *mp3_player)
    {
        if (mp3_player->objectName().isEmpty())
            mp3_player->setObjectName(QString::fromUtf8("mp3_player"));
        mp3_player->resize(400, 300);

        retranslateUi(mp3_player);

        QMetaObject::connectSlotsByName(mp3_player);
    } // setupUi

    void retranslateUi(QWidget *mp3_player)
    {
        mp3_player->setWindowTitle(QCoreApplication::translate("mp3_player", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class mp3_player: public Ui_mp3_player {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MP3_PLAYER_H
