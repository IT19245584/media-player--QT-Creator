/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen;
    QAction *actionOpen_2;
    QAction *actionplay;
    QAction *actionStop;
    QAction *actionPause;
    QAction *actionExit;
    QAction *mp3_player;
    QAction *actionAbout;
    QAction *actionMP3_Player_2;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menuOpen;
    QMenu *menuOpen_2;
    QMenu *menuVideo;
    QMenu *menuWeb_Cam;
    QMenu *menuPlayer;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/icons8-stop-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        actionOpen->setCheckable(false);
        actionOpen->setEnabled(true);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/icons8-audio-file-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon1);
        actionOpen_2 = new QAction(MainWindow);
        actionOpen_2->setObjectName(QString::fromUtf8("actionOpen_2"));
        actionOpen_2->setIcon(icon1);
        actionplay = new QAction(MainWindow);
        actionplay->setObjectName(QString::fromUtf8("actionplay"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/icons8-pause-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionplay->setIcon(icon2);
        QFont font;
        font.setPointSize(7);
        actionplay->setFont(font);
        actionStop = new QAction(MainWindow);
        actionStop->setObjectName(QString::fromUtf8("actionStop"));
        actionStop->setIcon(icon);
        actionPause = new QAction(MainWindow);
        actionPause->setObjectName(QString::fromUtf8("actionPause"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/icons8-circled-play-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPause->setIcon(icon3);
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("icons8-exit-64.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExit->setIcon(icon4);
        mp3_player = new QAction(MainWindow);
        mp3_player->setObjectName(QString::fromUtf8("mp3_player"));
        mp3_player->setIcon(icon1);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionMP3_Player_2 = new QAction(MainWindow);
        actionMP3_Player_2->setObjectName(QString::fromUtf8("actionMP3_Player_2"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 31));
        QFont font1;
        font1.setPointSize(11);
        font1.setBold(false);
        font1.setWeight(50);
        menubar->setFont(font1);
        menubar->setStyleSheet(QString::fromUtf8("background : #262626;\n"
"color:white;"));
        menuOpen = new QMenu(menubar);
        menuOpen->setObjectName(QString::fromUtf8("menuOpen"));
        menuOpen_2 = new QMenu(menubar);
        menuOpen_2->setObjectName(QString::fromUtf8("menuOpen_2"));
        menuVideo = new QMenu(menubar);
        menuVideo->setObjectName(QString::fromUtf8("menuVideo"));
        menuWeb_Cam = new QMenu(menubar);
        menuWeb_Cam->setObjectName(QString::fromUtf8("menuWeb_Cam"));
        menuPlayer = new QMenu(menubar);
        menuPlayer->setObjectName(QString::fromUtf8("menuPlayer"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        toolBar->setAutoFillBackground(false);
        toolBar->setStyleSheet(QString::fromUtf8(""));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        menubar->addAction(menuOpen->menuAction());
        menubar->addAction(menuOpen_2->menuAction());
        menubar->addAction(menuVideo->menuAction());
        menubar->addAction(menuPlayer->menuAction());
        menubar->addAction(menuWeb_Cam->menuAction());
        menuOpen->addAction(actionOpen_2);
        menuOpen_2->addAction(actionOpen);
        menuOpen_2->addAction(actionExit);
        menuVideo->addAction(actionplay);
        menuVideo->addAction(actionStop);
        menuVideo->addAction(actionPause);
        menuWeb_Cam->addAction(actionAbout);
        menuPlayer->addAction(actionMP3_Player_2);
        toolBar->addAction(actionOpen);
        toolBar->addAction(actionStop);
        toolBar->addAction(actionplay);
        toolBar->addAction(actionPause);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Lark Player", nullptr));
        actionOpen->setText(QCoreApplication::translate("MainWindow", "Open", nullptr));
#if QT_CONFIG(tooltip)
        actionOpen->setToolTip(QCoreApplication::translate("MainWindow", "Open A File", nullptr));
#endif // QT_CONFIG(tooltip)
        actionOpen_2->setText(QCoreApplication::translate("MainWindow", "Open", nullptr));
#if QT_CONFIG(tooltip)
        actionOpen_2->setToolTip(QCoreApplication::translate("MainWindow", "Open", nullptr));
#endif // QT_CONFIG(tooltip)
        actionplay->setText(QCoreApplication::translate("MainWindow", "play", nullptr));
#if QT_CONFIG(tooltip)
        actionplay->setToolTip(QCoreApplication::translate("MainWindow", "Play", nullptr));
#endif // QT_CONFIG(tooltip)
        actionStop->setText(QCoreApplication::translate("MainWindow", "Stop", nullptr));
#if QT_CONFIG(tooltip)
        actionStop->setToolTip(QCoreApplication::translate("MainWindow", "Stop", nullptr));
#endif // QT_CONFIG(tooltip)
        actionPause->setText(QCoreApplication::translate("MainWindow", "Pause", nullptr));
#if QT_CONFIG(tooltip)
        actionPause->setToolTip(QCoreApplication::translate("MainWindow", "Puase", nullptr));
#endif // QT_CONFIG(tooltip)
        actionExit->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
        mp3_player->setText(QCoreApplication::translate("MainWindow", "MP3 Player", nullptr));
        actionAbout->setText(QCoreApplication::translate("MainWindow", "About", nullptr));
        actionMP3_Player_2->setText(QCoreApplication::translate("MainWindow", "MP3 Player", nullptr));
        menuOpen->setTitle(QString());
        menuOpen_2->setTitle(QCoreApplication::translate("MainWindow", "File ", nullptr));
        menuVideo->setTitle(QCoreApplication::translate("MainWindow", "Video ", nullptr));
        menuWeb_Cam->setTitle(QCoreApplication::translate("MainWindow", "Option ", nullptr));
        menuPlayer->setTitle(QCoreApplication::translate("MainWindow", "Player", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("MainWindow", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
