/********************************************************************************
** Form generated from reading UI file 'mp3_player_.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MP3_PLAYER__H
#define UI_MP3_PLAYER__H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mp3_player_
{
public:
    QAction *actionExit;
    QAction *actionVideo_Player;
    QAction *actionAbout;
    QWidget *centralwidget;
    QProgressBar *progressBar;
    QPushButton *mute;
    QSlider *volume;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *file;
    QPushButton *play;
    QPushButton *pause;
    QPushButton *stop;
    QMenuBar *menubar;
    QMenu *menuLark_Player;
    QMenu *menuOption;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *mp3_player_)
    {
        if (mp3_player_->objectName().isEmpty())
            mp3_player_->setObjectName(QString::fromUtf8("mp3_player_"));
        mp3_player_->resize(800, 286);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/icons8-stop-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        mp3_player_->setWindowIcon(icon);
        actionExit = new QAction(mp3_player_);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        actionVideo_Player = new QAction(mp3_player_);
        actionVideo_Player->setObjectName(QString::fromUtf8("actionVideo_Player"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/icons8-play-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionVideo_Player->setIcon(icon1);
        actionAbout = new QAction(mp3_player_);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        centralwidget = new QWidget(mp3_player_);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(40, 100, 741, 41));
        progressBar->setValue(0);
        mute = new QPushButton(centralwidget);
        mute->setObjectName(QString::fromUtf8("mute"));
        mute->setGeometry(QRect(40, 170, 170, 39));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(mute->sizePolicy().hasHeightForWidth());
        mute->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(12);
        mute->setFont(font);
        mute->setStyleSheet(QString::fromUtf8("background :rgb(0, 0, 0);\n"
"border-radius:2px;\n"
"color:white;"));
        volume = new QSlider(centralwidget);
        volume->setObjectName(QString::fromUtf8("volume"));
        volume->setGeometry(QRect(240, 180, 501, 22));
        volume->setOrientation(Qt::Horizontal);
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(40, 40, 701, 41));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        file = new QPushButton(widget);
        file->setObjectName(QString::fromUtf8("file"));
        sizePolicy.setHeightForWidth(file->sizePolicy().hasHeightForWidth());
        file->setSizePolicy(sizePolicy);
        file->setFont(font);
        file->setStyleSheet(QString::fromUtf8("background :rgb(0, 0, 0);\n"
"border-radius:2px;\n"
"color:white;"));

        horizontalLayout->addWidget(file);

        play = new QPushButton(widget);
        play->setObjectName(QString::fromUtf8("play"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(play->sizePolicy().hasHeightForWidth());
        play->setSizePolicy(sizePolicy1);
        play->setFont(font);
        play->setStyleSheet(QString::fromUtf8("background :rgb(0, 0, 0);\n"
"border-radius:2px;\n"
"color:white;"));

        horizontalLayout->addWidget(play);

        pause = new QPushButton(widget);
        pause->setObjectName(QString::fromUtf8("pause"));
        sizePolicy1.setHeightForWidth(pause->sizePolicy().hasHeightForWidth());
        pause->setSizePolicy(sizePolicy1);
        pause->setFont(font);
        pause->setStyleSheet(QString::fromUtf8("background :rgb(0, 0, 0);\n"
"border-radius:2px;\n"
"color:white;"));

        horizontalLayout->addWidget(pause);

        stop = new QPushButton(widget);
        stop->setObjectName(QString::fromUtf8("stop"));
        sizePolicy1.setHeightForWidth(stop->sizePolicy().hasHeightForWidth());
        stop->setSizePolicy(sizePolicy1);
        stop->setFont(font);
        stop->setStyleSheet(QString::fromUtf8("background :rgb(0, 0, 0);\n"
"border-radius:2px;\n"
"color:white;"));

        horizontalLayout->addWidget(stop);

        mp3_player_->setCentralWidget(centralwidget);
        menubar = new QMenuBar(mp3_player_);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 26));
        menuLark_Player = new QMenu(menubar);
        menuLark_Player->setObjectName(QString::fromUtf8("menuLark_Player"));
        menuOption = new QMenu(menubar);
        menuOption->setObjectName(QString::fromUtf8("menuOption"));
        mp3_player_->setMenuBar(menubar);
        statusbar = new QStatusBar(mp3_player_);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        mp3_player_->setStatusBar(statusbar);

        menubar->addAction(menuLark_Player->menuAction());
        menubar->addAction(menuOption->menuAction());
        menuLark_Player->addAction(actionExit);
        menuOption->addAction(actionVideo_Player);
        menuOption->addAction(actionAbout);

        retranslateUi(mp3_player_);

        QMetaObject::connectSlotsByName(mp3_player_);
    } // setupUi

    void retranslateUi(QMainWindow *mp3_player_)
    {
        mp3_player_->setWindowTitle(QCoreApplication::translate("mp3_player_", "Lark Player", nullptr));
        actionExit->setText(QCoreApplication::translate("mp3_player_", "Exit", nullptr));
        actionVideo_Player->setText(QCoreApplication::translate("mp3_player_", "Video Player", nullptr));
        actionAbout->setText(QCoreApplication::translate("mp3_player_", "About", nullptr));
        mute->setText(QCoreApplication::translate("mp3_player_", "Mute", nullptr));
        file->setText(QCoreApplication::translate("mp3_player_", "File", nullptr));
        play->setText(QCoreApplication::translate("mp3_player_", "Play", nullptr));
        pause->setText(QCoreApplication::translate("mp3_player_", "Pause", nullptr));
        stop->setText(QCoreApplication::translate("mp3_player_", "Stop", nullptr));
        menuLark_Player->setTitle(QCoreApplication::translate("mp3_player_", "File", nullptr));
        menuOption->setTitle(QCoreApplication::translate("mp3_player_", "Option", nullptr));
    } // retranslateUi

};

namespace Ui {
    class mp3_player_: public Ui_mp3_player_ {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MP3_PLAYER__H
