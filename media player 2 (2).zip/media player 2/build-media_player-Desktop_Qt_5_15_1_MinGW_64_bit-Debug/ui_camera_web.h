/********************************************************************************
** Form generated from reading UI file 'camera_web.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CAMERA_WEB_H
#define UI_CAMERA_WEB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_camera_web
{
public:

    void setupUi(QWidget *camera_web)
    {
        if (camera_web->objectName().isEmpty())
            camera_web->setObjectName(QString::fromUtf8("camera_web"));
        camera_web->resize(400, 300);

        retranslateUi(camera_web);

        QMetaObject::connectSlotsByName(camera_web);
    } // setupUi

    void retranslateUi(QWidget *camera_web)
    {
        camera_web->setWindowTitle(QCoreApplication::translate("camera_web", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class camera_web: public Ui_camera_web {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CAMERA_WEB_H
