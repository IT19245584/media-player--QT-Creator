/********************************************************************************
** Form generated from reading UI file 'web_camera.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WEB_CAMERA_H
#define UI_WEB_CAMERA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_web_camera
{
public:

    void setupUi(QDialog *web_camera)
    {
        if (web_camera->objectName().isEmpty())
            web_camera->setObjectName(QString::fromUtf8("web_camera"));
        web_camera->resize(400, 300);

        retranslateUi(web_camera);

        QMetaObject::connectSlotsByName(web_camera);
    } // setupUi

    void retranslateUi(QDialog *web_camera)
    {
        web_camera->setWindowTitle(QCoreApplication::translate("web_camera", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class web_camera: public Ui_web_camera {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WEB_CAMERA_H
